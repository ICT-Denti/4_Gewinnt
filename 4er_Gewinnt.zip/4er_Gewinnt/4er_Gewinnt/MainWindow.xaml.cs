﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _4er_Gewinnt
{
  /// <summary>
  /// Interaktionslogik für MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
        Spiel_Brett spiel_Brett = null;
        Optionen Optionen = null;
        SolidColorBrush Farbe1 = null;
        SolidColorBrush Farbe2 = null;
    public MainWindow()
    {
      InitializeComponent();
    }

        private void Spiel_Click(object sender, RoutedEventArgs e)
        {
        if (spiel_Brett == null) { 
        spiel_Brett = new Spiel_Brett();
        spiel_Brett.Show();
        this.Hide();
        if(Farbe1 != null && Farbe2 != null) {
          spiel_Brett.spiel_Logik.player1_clr = Farbe1;
          spiel_Brett.spiel_Logik.player2_clr = Farbe2;
        }
        spiel_Brett.Closed += modularwindow_closed;             
        }
  

        }

        private void modularwindow_closed(object sender, EventArgs e)
        {
            this.Show();
            if (Optionen != null)
      {
        Farbe1 = Optionen.Farbe1;
        Farbe2 = Optionen.Farbe2;
      }
            spiel_Brett = null;
            Optionen = null;
        }

        private void Optionen_Click(object sender, RoutedEventArgs e)
        {
            if (Optionen == null)
            {
                Optionen = new Optionen();
                Optionen.Show();
                this.Hide();
                Optionen.Closed += modularwindow_closed;
            }
        }
    }
}
