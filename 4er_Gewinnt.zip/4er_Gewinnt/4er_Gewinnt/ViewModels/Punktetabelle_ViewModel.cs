﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4er_Gewinnt.ViewModels
{
    public class Punktetabelle_ViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged = (sender,e)=>{};
        public string Player1 { get; set; }
        public string Player2 { get; set; }
    }
}
