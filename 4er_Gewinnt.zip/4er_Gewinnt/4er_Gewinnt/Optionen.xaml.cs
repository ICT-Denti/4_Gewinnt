﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Xceed.Wpf.Toolkit;

namespace _4er_Gewinnt
{
  /// <summary>
  /// Interaktionslogik für Optionen.xaml
  /// </summary>
  public partial class Optionen : Window 
  {
    public SolidColorBrush Farbe1 { get; set; }
    public SolidColorBrush Farbe2 { get; set; }

    public Optionen()
    {
      InitializeComponent();
    }

  private void Abruch_Click(object sender, RoutedEventArgs e)
    {
      this.Close();
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
      var a = (ComboBoxItem)combobox1.SelectedItem;
      Farbe1 = (SolidColorBrush)a.Background;
      var b = (ComboBoxItem)combobox2.SelectedItem;
      Farbe2 = (SolidColorBrush)b.Background;
      this.Close();
    }
  }
}
