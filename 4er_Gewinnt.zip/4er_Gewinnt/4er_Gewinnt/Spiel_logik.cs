﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace _4er_Gewinnt
{
    public enum Feld_status : byte {leer=0,player1,player2 };

    public class Spiel_logik
    {
        public Feld_status[][] Feld = new Feld_status[7][] {
        new Feld_status[6],
        new Feld_status[6],
        new Feld_status[6],
        new Feld_status[6],
        new Feld_status[6],
        new Feld_status[6],
        new Feld_status[6]
        };
  

        public Feld_status current_player = Feld_status.player1;


        public ObservableCollection<Feld_Farbe> Feld_clr { get; set; } = new ObservableCollection<Feld_Farbe>();

        public SolidColorBrush player1_clr { get; set; } = new SolidColorBrush(Color.FromRgb(255,1,1));
        public SolidColorBrush player2_clr { get; set; } = new SolidColorBrush(Color.FromRgb(255, 247, 0));
        public SolidColorBrush leer_clr { get; set; } = new SolidColorBrush( Color.FromArgb(255,255, 255, 255));
        

        public Spiel_logik()
        {
            BrettInit();
        }
        public void BrettInit()
        {
            if (Feld_clr.Count == 0)
                for (int i = 0; i < 42; i++)
                {

                    Feld_clr.Add(new Feld_Farbe() { Color = leer_clr });

                }
            else
            {
                for (int i = 0; i < 42; i++)
                {
                 
                    Feld_clr[i].Color = leer_clr;
                    Feld[ i  / 6][i % 6] = Feld_status.leer;
                }
              
            }
        }
       
       public void makeMove(int col)
        {
            for (int i = 0; i < 6; i++)
                if (Feld[col][i] == Feld_status.leer)
                {    
                    SetFeld(col, i,i+col*6);
                    if(Checkifwin(col, i))
                    {
                        if(current_player==Feld_status.player1)
                        MessageBox.Show("Spieler 1 hat gewonnen");
                        else
                        MessageBox.Show("Spieler 2 hat gewonnen");
                        BrettInit();

                    }
                    changePlayer();
                    return;
                }
        }

        private void SetFeld(int col, int row, int pos)
        {
            switch (current_player)
            {
                case Feld_status.player1:
                    Feld_clr[pos].Color = player1_clr;                
                    Feld[col][row] = Feld_status.player1;
                    break;
                case Feld_status.player2:
                    Feld_clr[pos].Color = player2_clr;
                    Feld[col][row] = Feld_status.player2;
                    break;
            }
          
        }

        private bool Checkifwin(int col, int row)
        {
            int North=0;
            int NorthEast=0;
            int East=0;
            int SouthEast=0;
            int South=0;
            int SouthWest=0;
            int West=0;
            int NorthWest=0;
            bool North_open =       true;
            bool NorthEast_open =   true;
            bool East_open =        true;
            bool SouthEast_open =   true;
            bool South_open =       true;
            bool SouthWest_open =   true;
            bool West_open =        true;
            bool NorthWest_open =   true;

            for (int i = 1; i <= 3; i++)
            {

                if (North_open &&
                    col + i <= 6 &&
                    Feld[col + i][row] == current_player)
                    North++;
                else
                    North_open = false;

                if (NorthEast_open &&
                    col + i <= 6 && row + i <= 5 &&
                    Feld[col + i][row + i] == current_player)
                    NorthEast++;
                else
                    NorthEast_open = false;

                if (East_open &&
                    row + i <= 5 &&
                    Feld[col][row + i] == current_player) 
                    East++;
                else
                    East_open = false;

                if (SouthEast_open &&
                    col - i >= 0 && row + i <= 5 &&
                    Feld[col - i][row + i] == current_player) 
                    SouthEast++;
                else
                    SouthEast_open = false;

                if (South_open &&
                    col - i >= 0 &&
                    Feld[col - i][row    ] == current_player) 
                    South++;
                else
                    South_open = false;

                if (SouthWest_open && row - i >= 0 && col - i >= 0 &&
                    Feld[col - i][row - i] == current_player) 
                    SouthWest++;
                else
                    SouthWest_open = false;

                if (West_open &&
                    row - i >= 0 &&
                    Feld[col][row - i] == current_player) 
                    West++;
                else
                    West_open = false;

                if (NorthWest_open &&
                    col + i <= 6 && row - i >= 0 &&
                    Feld[col + i][row - i] == current_player) 
                    NorthWest++;
                else
                    NorthWest_open = false;


            }
            if (
                North + South+1 >= 4 ||
                NorthEast + SouthWest+1 >= 4 ||
                NorthWest + SouthEast+1 >= 4 ||
                East + West+1 >= 4)
            {
                return true;
            }
            return false;
        }

        private void changePlayer()
        {
            if (current_player == Feld_status.player1)
                    current_player = Feld_status.player2;
            else    current_player = Feld_status.player1;
        }
    }
    
    public class Feld_Farbe:INotifyPropertyChanged
    {
        private SolidColorBrush feld_clr;
        public SolidColorBrush Color {
            get { return feld_clr; }
            set {
                if (feld_clr != value)
                {
                    feld_clr = value;
                    NotifyPropertyChanged("Color");
                }
            } }

        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged(string propName)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }
    }
}
