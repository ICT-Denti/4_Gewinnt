﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _4er_Gewinnt
{
    /// <summary>
    /// Interaktionslogik für Spiel_Brett.xaml
    /// </summary>
    public partial class Spiel_Brett : Window
    {
        public Spiel_logik spiel_Logik; 
        public Spiel_Brett()
        {
            spiel_Logik = new Spiel_logik();
            InitializeComponent();
            DataContext = spiel_Logik;
            
        }

        private void Column_Click(object sender, RoutedEventArgs e)
        {
            spiel_Logik.makeMove(int.Parse((string)((Button)sender).Tag));
        }

        private void New_Click(object sender, RoutedEventArgs e)
        {
            spiel_Logik.BrettInit();
        }
    }

  // Voriges Player Icon vom Xaml
  // <Ellipse Fill="#FFFFF700" Height="56" Margin="122,346,122,0" Stroke="Black" VerticalAlignment="Top" Width="56" HorizontalAlignment="Center" />

}
